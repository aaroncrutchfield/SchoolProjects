package graphing;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;

class GBar
{
    String text;
    int value;
    GBar(String t, int v)
    {
        text=t;
        value =v;
    }
}

public class Graphing extends JFrame{

    ArrayList<GBar> gbarArr = new ArrayList<GBar>();
    String title;

    Graphing(String filename)
    {
        super();
        init(filename);
        setTitle(title);
        setSize(600,600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    private void init(String filename)
    {
        File file = new File(filename);
        try {
            Scanner input = new Scanner(file);
            title = input.nextLine().trim();
            while(input.hasNextLine())
            {
                String s = input.nextLine();
                int index = s.indexOf(';');
                if (index > 0)
                {
                    String name = s.substring(0, index).trim();
                    String sValue = s.substring(index+1).trim();
                    int value = Integer.parseInt(sValue);
                    gbarArr.add(new GBar(name, value));
                }
            }
            input.close();
        } 
        catch (FileNotFoundException e) {
            throw new RuntimeException("file not found: "+ filename);
        }
    }

    // Find the maximum width of the strings in pixels
    int getMaxTextWidth(ArrayList<GBar> garr, FontMetrics fm)
    {
        int maxValue=0;
        for (int i=0; i < garr.size(); i++)
        {
            int width = fm.stringWidth(garr.get(i).text);
            if (width > maxValue)
                maxValue = width;
        }
        return maxValue;            
    }

    // Find the maximum value in the ArrayList
    int getMaxBarWidth(ArrayList<GBar> garr)
    {
        int maxValue=0;
        for (int i=0; i < garr.size(); i++)
        {
            int value = garr.get(i).value;
            if (value > maxValue)
                maxValue = value;
        }
        return maxValue;            
    }
    public void paint(Graphics g)
    {
        super.paint(g);
        Dimension dimen = getSize();
        Insets insets = getInsets();
        int top = insets.top;
        int left = insets.left;
        int right = insets.right;
        int bottom = insets.bottom;

        Font font = g.getFont();
        FontMetrics fm = getFontMetrics(font);
        int fontHeight = fm.getHeight();
        int maxAscent = fm.getMaxAscent();
        
        int myBorder=10;
        g.setColor(Color.red);
        g.fillRect(0, top, dimen.width, myBorder);
        g.fillRect(left, 0, myBorder, dimen.height);
        g.fillRect(dimen.width-right-myBorder, 0, myBorder, dimen.height);
        g.fillRect(0, dimen.height-bottom-myBorder, dimen.width, myBorder);

        int strMaxWidth = left + getMaxTextWidth( gbarArr, fm) + myBorder;
        int x_bar_start =  strMaxWidth +1/* a little white space pad*/; 
        
        
        
        int barMaxValue = getMaxBarWidth(gbarArr);
        double scale = (dimen.width -x_bar_start - right - 2*myBorder) / (double) barMaxValue;
        
        int y_start = top+myBorder;
        
        int bar_height = fontHeight;
        
        for (int i=0; i < gbarArr.size(); i++)
        {
            String text = gbarArr.get(i).text;
            int strWidth = fm.stringWidth(text);
            int value =gbarArr.get(i).value;
            int scaledValue = (int)(value * scale); 
            
            g.setColor(Color.black);
            g.drawString(text, strMaxWidth - strWidth, y_start + maxAscent);
            
            g.setColor(Color.green);
            g.fillRect(x_bar_start, y_start, scaledValue, bar_height);
            
            y_start += fontHeight + 10/*  a little space between rows */;
        }
        g.drawLine(strMaxWidth, top+myBorder, strMaxWidth, dimen.height-bottom-myBorder);
    }
    

    public static void main(String[] args) {
        
        Graphing gb= new Graphing("graphing.txt");

    }

}
