package chess;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JFrame;



public class ChessBoard extends JFrame
{
   private Image loadImage(String fileName) 
        {
          return new ImageIcon(fileName).getImage();
        }
    
    public ChessBoard()
    {
        super("Chess ... a great game");
        ChessPiece.readInImages();
        setSize(800, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    

    public void paint(Graphics g)
    {      
       super.paint(g);
       Insets insets = getInsets();
       int top = insets.top;
       int bottom = insets.bottom;
       int left = insets.left;
       int right = insets.right;
       
       int height = getHeight();
       int width = getWidth();
       
       int cell_h = (height-top-bottom)/8;
       int cell_w = (width-left-right)/8;
       BoardDimensions boardDimensions = new 
               BoardDimensions(left, top, cell_w, cell_h);
      
       int x,y;
       
       for (int row=0; row < 8; row++)
       {
           y = top + row*cell_h;
           for (int col=0; col < 8; col++)
           {
               x = left + col*cell_w;
               boolean greenColor = (row+col) %2 == 1;
               if (greenColor)
               {
                   g.setColor(Color.green);
               }
               else
               {
                   g.setColor(Color.white);
               }
               g.fillRect(x, y, cell_w, cell_h);
              
           }
           
           // Black Pawns
           for (int col=0; col < 8; col++)
           {
               Piece p =new Piece(PieceType.Pawn, ColorType.black, col, 1);
               p.drawInPosition(g, boardDimensions);
           }
           // White Pawns
           for (int col=0; col < 8; col++)
           {
               Piece p =new Piece(PieceType.Pawn, ColorType.white, col, 6);
               p.drawInPosition(g, boardDimensions);
           }
           // Helper Array
           PieceType[] kingRow = {PieceType.Rook, PieceType.Knight, PieceType.Bishop, PieceType.Queen,
                                  PieceType.King, PieceType.Bishop, PieceType.Knight, PieceType.Rook};
           
           // Black King Row
           for (int col =0; col < kingRow.length; col++)
           {
               Piece p =new Piece(kingRow[col], ColorType.black, col, 0);
               p.drawInPosition(g, boardDimensions);           
           }

           // White King Row
           for (int col =0; col < kingRow.length; col++)
           {
               Piece p =new Piece(kingRow[col], ColorType.white, col, 7);
               p.drawInPosition(g, boardDimensions);           
           }
           
       }
       
      
     
    
       
    }

    public static void main(String[] args) 
    { 
        ChessBoard imageStuff = new ChessBoard(); 
    } // end of main


}