package file_operations;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;

public class FileOperations 
{
    StringTokenizer parseCommand;


    public void delete()
    {
        File f = getFile();
        if (f != null)
        {
            System.out.println("deleting "+ f.getAbsolutePath());
            if (f.delete())
                System.out.println(" Successful delete");
            else
                System.out.println(" unSuccessful delete");
        }
    }
    public void rename()
    {
        File f = getFile();
        if (f != null)
        {
            System.out.println("renaming "+ f.getAbsolutePath());
            File f2 = getFile();
            if (f.renameTo(f2))
                System.out.println(" Successful rename");
            else
                System.out.println(" unSuccessful rename");
        }

    }
    public void list()
    {
        File f = getFile();
        if (f != null)
        {
            System.out.println("Listing files for "+ f.getAbsolutePath());
            if (f.exists())
            {
                String[] files = f.list();
                if (files != null)
                {
                    for (int i=0; i < files.length; i++)
                        System.out.println(files[i]);
                }
            }
            else
                System.out.println("list error -  Non-existent:" + f.getAbsolutePath());
        }
    }
    public void size()
    {
        File f = getFile();
        if (f != null)
        {
            if (f.exists())
            {
                System.out.print("size for "+ f.getAbsolutePath());
                long len = f.length();
                System.out.println(" is = "+len);
            }
            else
                System.out.println("size error -  Non-existent:" + f.getAbsolutePath());
        }

    }
    public void lastModified()
    {
        File f = getFile();
        if (f != null)
        {
            if (f.exists())
            {
                System.out.println("lastModified for "+ f.getAbsolutePath());
                long date = f.lastModified();
                System.out.println(" date="+new Date(date));
            }
            else
                System.out.println("lastModified error Non-existent:" + f.getAbsolutePath());
        }
    }
    public void mkdir()
    {
        File f = getFile();
        if (f != null)
        {
            if (f.mkdir())
                System.out.println("mkdir successful: " + f.getAbsolutePath());
            else
                System.out.println("mkdir unsuccessful: " + f.getAbsolutePath());
        }
    }
    public void createFile()
    {
        File f = getFile();
        if (f!= null)
        {
            try {
                PrintWriter pw = new PrintWriter(f);
                String token = getNextToken();
                while (token != null)
                {
                    pw.println(token);
                    token = getNextToken();
                }
                pw.close();
                System.out.println("created file for "+ f.getAbsolutePath());
            } catch (FileNotFoundException e) {
                System.out.println("createFile can't create: "+ f.getAbsolutePath());
            }
        }
    }

    public void printFile()
    {
        File f = getFile();
        if (f != null)
        {
            try {
                Scanner scan = new Scanner(f);
                while (scan.hasNextLine())
                {
                    System.out.println(scan.nextLine());
                }
                scan.close();
                System.out.println("printed file for "+ f.getAbsolutePath());
            } catch (FileNotFoundException e) {
                System.out.println("printFile can't open: "+ f.getAbsolutePath());
            }
        }
    }

    void printUsage()
    {
        System.out.println("?");
        System.out.println("quit");
        System.out.println("delete filename");
        System.out.println("rename oldFilename newFilename");
        System.out.println("size filename");
        System.out.println("lastModified filename");
        System.out.println("list dir");
        System.out.println("printFile filename");
        System.out.println("createFile filename <remaining tokens written to file>");
        System.out.println("mkdir dir");
    }

    private String getNextToken()
    {
        if (parseCommand.hasMoreTokens())
            return parseCommand.nextToken();
        else
            return null;
    }
    public File getFile()
    {
        File f = null;
        String fileName = getNextToken();
        if (fileName == null)     
            System.out.println("Missing a File name");                  
        else
            f = new File(fileName);      

        return f;
    }


    public boolean processCommandLine(String line)    
    {
        if (line == null)
            return false;

        boolean retval = true;
        parseCommand = new StringTokenizer(line);
        String cmd = getNextToken();
        if (cmd == null)
        {
            System.out.println("No command specified");                
        }
        else
        {
            switch(cmd)
            {
            case "?":
                printUsage();
                break;

            case "quit":                    
                retval = false;
                break;
            case "delete":
                delete();
                break;
            case "rename":
                rename();
                break;
            case "size":
                size();
                break;
            case "lastModified":
                lastModified();
                break;
            case "list":
                list();
                break;
            case "printFile":
                printFile();
                break;
            case "createFile":
                createFile();
                break;
            case "mkdir":
                mkdir();
                break;
            default:
                System.out.println("Unrecognized command: "+cmd);
                break;

            }
        }
        System.out.println("***********************************************");
        return retval;


    }

    void processCommandFile(String commandFile)
    {
        File f = new File(commandFile);
        Scanner inputScan = null;
        try {
            inputScan = new Scanner(f);
        } catch (FileNotFoundException e) {
            System.out.println("command file does not exist: "+f.getAbsolutePath());
            return;
        }
        
        String command;
        do
        {
            System.out.println("===>");
            if (inputScan.hasNext())
                command = inputScan.nextLine();
            else
                break;
            System.out.println("Processing: "+command);
        } while (processCommandLine(command));

        System.out.println("Done with command file: "+ f.getAbsolutePath());
        inputScan.close();
    }
    public static void main(String[] args) 
    {
        FileOperations fo= new FileOperations();
        for (int i=0; i < args.length; i++)
        {
            System.out.println("\n\n============  Processing " + args[i] +" =======================\n");
            fo.processCommandFile(args[i]);
        }

        System.out.println("Done with FileOperations");
    }
}