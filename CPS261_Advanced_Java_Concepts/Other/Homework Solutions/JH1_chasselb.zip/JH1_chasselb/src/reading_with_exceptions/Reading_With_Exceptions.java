package reading_with_exceptions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Reading_With_Exceptions {

	// Copy the contents of the file to the screen
	void printToScreen(String filename)
	{
		Scanner scan = null;
		try {
			FileInputStream fis = new FileInputStream(filename);
			scan = new Scanner(fis);
			while (scan.hasNextLine())
			{
				System.out.println(scan.nextLine());
			}
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("printToScreen: can't open: " + filename);
		}
		finally
		{
			if (scan != null)
				scan.close();
		}
	}


	void process(String inputFilename)
	{
		Scanner scan=null;
		PrintStream ps = null;
		String outFilename = null;
		try {
			FileInputStream fis = new FileInputStream(inputFilename);
			scan = new Scanner(fis);

			outFilename = scan.next();
			FileOutputStream fos = new FileOutputStream(outFilename);
			System.out.println(outFilename+ " created with the following output: ");
			ps = new PrintStream(fos);
			int printCount =0;

			int numIntsToRead =-1 ;
			try
			{
				numIntsToRead = scan.nextInt();
				if (numIntsToRead < 0)
					System.out.println("Negative count ... defaulting to reading all integers");
			}
			catch(InputMismatchException e)
			{
				System.out.println("Read in a bad count ... defaulting to reading all integers" );
				scan.next(); // Skip over bad input
			}

			while (scan.hasNext())
			{
				// A little trick here ... if we are reading everything then numIntsToRead starts at -1
				// and will be decremented so it can never == 0. 
				if (numIntsToRead == 0)
					break;

				try
				{
					int value = scan.nextInt();
					numIntsToRead -= 1;
					ps.print(value +" ");
					printCount += 1;
					if (printCount % 10 == 0)
						ps.println();
				}
				catch(InputMismatchException e)
				{
					System.out.println("Bad int read ... skipping" );
					scan.next(); // Skip over bad input
				}

			}


		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("Unable to open: " + inputFilename);
		}
		finally
		{
			if (scan != null)
				scan.close();
			if (ps != null)
				ps.close();
		}
		if (outFilename != null)
			printToScreen(outFilename);
	}



    public static void main(String[] args) {
        Reading_With_Exceptions rwe = new Reading_With_Exceptions();
        for (int i=0; i < args.length; i++)
        {
            System.out.println("\n\n=========== Processing "+ args[i] + " ==========\n");
            rwe.process(args[i]);
        }

    }

}
