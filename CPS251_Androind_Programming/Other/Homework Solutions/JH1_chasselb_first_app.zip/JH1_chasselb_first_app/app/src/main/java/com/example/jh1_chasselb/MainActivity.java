package com.example.jh1_chasselb;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends Activity
        implements OnClickListener {
    /**
     * Called when the activity is first created.
     */
    TextView display = null;
    Button b1, b2, bclear;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Set up click listeners for all the buttons
        b1 = (Button) findViewById(R.id.b1);
        b1.setOnClickListener(this);
        b2 = (Button) findViewById(R.id.b2);
        b2.setOnClickListener(this);
        bclear = (Button) findViewById(R.id.clear);
        bclear.setOnClickListener(this);
        display = (TextView) findViewById(R.id.display);
    }

    // ...
    public void onClick(View v) {

        Log.d("Mine", "onClick");

        switch (v.getId()) {
            case R.id.b1:
                display.append(b1.getText());
                break;
            case R.id.b2:
                display.append(b2.getText());
                break;
            case R.id.clear:
                display.setText("");
                break;
            default:
                Log.d("Mine","Shouldn't get this message");
                break;
        }
    }
}