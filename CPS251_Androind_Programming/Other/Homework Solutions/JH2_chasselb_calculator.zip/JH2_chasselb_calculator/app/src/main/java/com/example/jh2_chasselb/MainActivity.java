package com.example.jh2_chasselb;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends Activity implements OnClickListener {
	TextView display;
	CalculatorEvaluation calculatorEvaluation = new CalculatorEvaluation();
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        int[] digitResources ={R.id.b0, R.id.b1, R.id.b2, R.id.b3, R.id.b4, R.id.b5,
        		R.id.b6, R.id.b7, R.id.b8, R.id.b9, R.id.backSpace, R.id.equals,
        		R.id.mult, R.id.plus, R.id.div, R.id.minus, R.id.equals, R.id.clear};
        
        for (int i=0; i < digitResources.length; i++)
        {
        	Button b = (Button)findViewById(digitResources[i]);
        	b.setOnClickListener(this);
        }
        
        display = (TextView)findViewById(R.id.display);
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


	@Override
	public void onClick(View v) {
        
        // display is assumed to be the TextView used for the Calculator display
        String currDisplayValue = display.getText().toString();
    
        Button b = (Button)v;  // We assume only buttons have onClickListeners for this App
        String label = b.getText().toString();  // read the label on the button clicked
                 
         switch (v.getId()) 
         {       
             case R.id.clear:
                 // Do whatever you do for clear
            	 display.setText("");
                 break;
             case R.id.plus:
             case R.id.minus:
             case R.id.mult:
             case R.id.div:
                 String operator = label;
                 // Do whatever you need to do when this button is pressed
                 calculatorEvaluation.update(operator, currDisplayValue);
                 display.setText("");
                 
                 break;
             case R.id.equals:
                 // Do whatever you need to do when the "=" button is pressed
            	 String nextValue = calculatorEvaluation.equalsCalculation(currDisplayValue);
            	 display.setText(nextValue);
                 break;
                 
             case R.id.backSpace:
                 // Do whatever you need to do when the back space button is pressed
            	 display.setText(currDisplayValue.substring(0, currDisplayValue.length()-1));
                 break;
             default:
                 // If the button isn't one of the above, it must be a digit
                 String digit = label;// This is the digit pressed
                 display.append(digit);
                 break;
         }
     }
}
