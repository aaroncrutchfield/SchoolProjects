package net.wcc.ajcrutchfield.jh5_ajcrutchfield_hangman;

/**
 * Created by AaronC on 10/4/2015.
 */
public interface HangmanUpdate {
    public void updateMessage(String s);
    public void gameIsDone(boolean winner);
}
