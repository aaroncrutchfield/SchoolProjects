package net.wcc.ajcrutchfield.JH7_ajcrutchfield;

/**
 * Created by AaronC on 11/24/2015.
 */
public interface PartOperations {
    public void newPart(String partNumber);
}
