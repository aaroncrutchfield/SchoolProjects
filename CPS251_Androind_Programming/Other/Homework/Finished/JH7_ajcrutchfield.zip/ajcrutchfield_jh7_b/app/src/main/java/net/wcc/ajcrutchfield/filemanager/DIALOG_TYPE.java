package net.wcc.ajcrutchfield.filemanager;

//had to put this in an different file to make public and be able to utilize
public enum DIALOG_TYPE {Open, Delete}
